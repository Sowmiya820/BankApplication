package Banking;
import java.util.ArrayList;
import java.util.Scanner;
public class Bank {
private ArrayList<Account> accounts;
private Scanner scanner;
private Database database;

public Bank()
{
	accounts=new ArrayList<>();
	scanner=new Scanner(System.in);
	database=new Database();
	loadAccountsFromDatabase();
	
}
public void start()
{
	while(true)
	{
		System.out.println("\n ----Welcome to Banking Application----");
		System.out.println("1. Create Account");
		System.out.println("2. Deposit");
		System.out.println("3. Withdraw");
		System.out.println("4. Check Balance");
		System.out.println("5. View Transaction History");
		System.out.println("6. Transfer Funds");
		System.out.println("7. Generate Report");
		System.out.println("8. Update");
		System.out.println("9. Exit");
		System.out.println("Choose an option:");
		int choice=scanner.nextInt();
		switch(choice)
		{
		case 1:
			createAccount();
			break;
		case 2:
			deposit();
            break;
		case 3:
			withdraw();
			break;
		case 4:
			viewAccount();
			break;
		case 5:
			viewTransactionHistory();
			break;
		case 6:
			transferFunds();
			break;
		case 7:
			generateReportsMenu();
			break;
		case 8:
			System.out.println("Enter AccountId to update:");
			int account_id=scanner.nextInt();
			  scanner.nextLine();
			updateCustomerDetails(account_id);
			break;
		case 9:
			System.out.println("Thank u for using the Banking Application");
			database.closeConnection();
			return;
			default:
				System.out.println("Invalid choice.Please try again.");
		}
	}
}
private void createAccount()
{ 
	
	System.out.println("Enter Customer id:");
	int customerid=scanner.nextInt();
	if(String.valueOf(customerid).length()!=5)
	{
		System.out.println("Customer Id must be 5 digits.");
		return;
	}
	
	
		System.out.print("Enter account type(s for Savings,c for Current):");
		char accounttypeinput=scanner.next().charAt(0);
		String accountType;
		if(accounttypeinput=='s' || accounttypeinput=='S')
		{
			accountType="Savings";
         }
		else if(accounttypeinput=='c' || accounttypeinput=='C')
		{
			accountType="Current";
		}
		else
		{
			System.out.println("Invalid account type entered. Defaulting to Savings.");
			accountType="Savings";
		}
	
	System.out.print("Enter your name:");
	scanner.nextLine();
	String name=scanner.nextLine();
	System.out.print("Enter ur phone number:");
	String phoneNumber=scanner.nextLine();
	if(String.valueOf(phoneNumber).length()!=10)
	{
		System.out.println("Phone number must be 10 digits.");
		return;
	}
	System.out.print("Enter ur address:");
	
	String address=scanner.nextLine();


	Account account=new Account(customerid,accountType,name,phoneNumber,address);
	database.insertAccount(account);
	System.out.println("Account created  successfully and ur account id is:"+account.getAccountId());
}
	private void deposit()
	{
		System.out.print("Enter account Id:");
		int accountId=scanner.nextInt();
		Account account=findAccount(accountId);
		if(account!= null)
		{
			System.out.print("Enter amount to deposit:");
				double amount=scanner.nextDouble();
				account.deposit(amount);
				database.updateAccountBalance(account);
				System.out.println("Deposit successful! New balance:"+account.getBalance());
		}
		else
		{
			System.out.println("Account not found.");
		}
	}
	private void withdraw()
	{
		System.out.print("Enter account Id:");
		int accountId=scanner.nextInt();
		Account account=findAccount(accountId);
		if(account!= null)
		{
			System.out.print("Enter amount to withdraw:");
				double amount=scanner.nextDouble();
				if(account.withdraw(amount))
				{
					database.updateAccountBalance(account);
					System.out.println("Withdrawal successful! New balance:"+account.getBalance());
				}
				else
				{
					System.out.println("Insufficient funds.");
				}
	}
		else
		{
			System.out.println("Account not found.");
		}
	
}
	private void viewAccount()
	{
		System.out.print("Enter account Id:");
		int accountId=scanner.nextInt();
		Account account=findAccount(accountId);
		if(account!=null)
		{
			System.out.println("Account id:"+account.getAccountId());
			System.out.println("Customer id:"+account.getCustomerId());
		
			System.out.println("Name:"+account.getName());
			System.out.println("Phone Number:"+account.getPhoneNumber());
			System.out.println("Address:"+account.getAddress());
			System.out.println("Account Type:"+account.getAccountType());
			System.out.println("Balance:"+account.getBalance());
			
		}
		else
		{
			System.out.println("Account not found");
		}
	}
	private void viewTransactionHistory()
	{
		System.out.print("Enter account id:");
		int accountid=scanner.nextInt();
		Account account=findAccount(accountid);
		if(account!=null)
		{
			account.printTransactionHistory();
		}
		else
		{
			System.out.println("Account not found.");
		}
	}
	private void transferFunds()
	{
		System.out.print("Enter source account ID:");
		int accountId=scanner.nextInt();
		Account sourceAccount=findAccount(accountId);
		if(sourceAccount==null)
		{
			System.out.println("Source account not found");
			return;
		}
		System.out.print("Enter ur destination account ID:");
		int destinationAccountId=scanner.nextInt();
		Account destinationAccount=findAccount(destinationAccountId);
		if(destinationAccount==null)
		{
			System.out.println("Destination account not found");
			return;
		}
		System.out.println("Enter amount to transfer:");
		double amount=scanner.nextDouble();
		if(amount<=0)
		{
			System.out.println("Transfer amount must be positive");
			return;
		}
		if(sourceAccount.getBalance()<amount)
		{
			System.out.println("Insufficient funds in the source account.Available Balance:"+sourceAccount.getBalance());
			return;
		}
		sourceAccount.withdraw(amount);
		destinationAccount.deposit(amount);
		database.updateAccountBalance(sourceAccount);
		database.updateAccountBalance(destinationAccount);
		System.out.printf("Successfully transfered %.2f from Account id: %d to Account id: %d.%n",amount,accountId,destinationAccountId);
		
	}
	private Account findAccount(int accountId)
	{
		
		for(Account account:accounts)
	{
	if(account.getAccountId()==accountId)
	{
		return account;
	}

	}
		return null;
	}


		 
	private void generateReportsMenu() 
	{
		while(true)
		{
		System.out.println("......All Generating Reports.....\n");
		System.out.println("1.Customer Details");
		System.out.println("2.Total Balance");
		System.out.println("3.Account type Count");
		System.out.println("4.Exit");
		int choice = scanner.nextInt();
		switch(choice)
		{
		case 1:
			customerDetails();
			break;
		case 2:
			totalBalance();
			break;
		case 3:
			AccounttypeCount();
			break;
		case 4:
			System.out.println("Thank u");
			return;
		default:
			System.out.println("Choose the correct option");
		}
		
	}
	}
	private void customerDetails()
	{
		System.out.println("..............Customer detail Report............");
		System.out.printf("%-15s %-15s %-15s %-15s %-15s","Account Id"," Customer Name","Customer Id","Account Type","Phone Number","Address");
		System.out.println("----------------------------------------------------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------------------------------------------------");
		
		for(Account account :accounts)
		{
			System.out.printf("%-15d %-20s %-15d %-15s %-15s %-30s%n",account.getAccountId(),account.getName(),account.getCustomerId(),account.getAccountType(),account.getPhoneNumber(),account.getAddress());
		}
	}
	private void totalBalance()
	{
		double totalAmount = 0.0;
		for(Account account : accounts)
		{
			totalAmount+=account.getBalance();	
		}
		System.out.printf("Total Balance :%.2f" ,totalAmount);
	}
	
	private void AccounttypeCount()
	{
		int s_count=0;
		int c_count=0;
		for(Account account : accounts)
		{
			if(account.getAccountType().equalsIgnoreCase("Savings"))
			{
				s_count++;
			}
			else
			{
				c_count++;
			}
		}
		System.out.println("Savings Account:"+s_count);
		System.out.println("Current Account:"+c_count);
	}
	private void updateCustomerDetails(int account_id)
	{
	
		Account account=findAccount(account_id);
		if(account!=null)
		{
			System.out.println("Existing account:");
			System.out.println("Name:"+account.getName());
			System.out.println("Phone Number:"+account.getPhoneNumber());
			System.out.println("Address:"+account.getAddress());
		}
		else
		{
			System.out.println("Account not found");
		}
		
		System.out.println("Enter your name for updating:");
   String s=scanner.nextLine();

   System.out.print("Enter Phone numberfor updating:");
   String p=scanner.nextLine();
   System.out.print("Enter ur address for updating:");
   String a=scanner.nextLine();
   if(!(s.isEmpty()))
   {
	   account.setName(s);
   }
   if(!(p.isEmpty()))
   {
	   account.setPhoneNumber(p);
   }
   if(!(a.isEmpty()))
   {
	   account.setAddress(a);
   }
   database.updateAccountDetails(account);
   System.out.println("After updating the account details:");
   
	System.out.println("Name:"+account.getName());
	System.out.println("Phone Number:"+account.getPhoneNumber());
	System.out.println("Address:"+account.getAddress());
		
	    
	}

	
	
	private void loadAccountsFromDatabase()
	{
		 accounts=database.getAllAccounts();
	}	
}
