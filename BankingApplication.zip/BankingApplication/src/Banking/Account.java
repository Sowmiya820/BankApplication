package Banking;
import java.util.ArrayList;

public class Account {
	private static int accountCounter=1;
	private int  account_id;
	private int customer_id;
	private String accountType;
	private double balance;
	private String name;
	private String phoneNumber;
	private String address;
	private ArrayList<String> transactionHistory;
	
	public Account(int customer_id,String accountType,String name,String phoneNumber,String address)
	{
		this.account_id=accountCounter++;
		this.customer_id=customer_id;
		this.accountType=accountType;
		this.balance=0.0;
		this.name=name;
		this.phoneNumber=phoneNumber;
		this.address=address;
	  this.transactionHistory=new ArrayList<>();
		
	}
	public String getName()
	{
		return name;
	}
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	public String getAddress()
	{
		return address;
	}
	public int getAccountId()
	{
		return account_id;
	}
	public int getCustomerId()
	{
		return customer_id;
	}
	public String getAccountType()
	{
		return accountType;
	}
	public double getBalance()
	{
		return balance;
	}
	public void deposit(double amount)
	{
		if(amount>0) {
			balance+=amount;
			transactionHistory.add("Doposited:"+Double.toString(amount));
		}
	}
	public boolean withdraw(double amount)
	{
		if(amount> 0 && balance>=amount)
		{
			balance-=amount;
			transactionHistory.add("Withdrew:"+Double.toString(amount));
			return true;
		}
		return false;
		
	}
	public void printTransactionHistory()
	{
		System.out.println("Transaction History for Account ID:"+account_id);
		for(String transaction:transactionHistory)
		{
			System.out.println(transaction);
			
		}
	}
	public void setAccountId(int account_id)
	{
		this.account_id=account_id;
		
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public void setPhoneNumber(String phoneNumber)
	{
	this.phoneNumber=phoneNumber;
	}
	public void setAddress(String address)
	{
		this.address=address;
	}
	
	
}
	
	
	
	
	


