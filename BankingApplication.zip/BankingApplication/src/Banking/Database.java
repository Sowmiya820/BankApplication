package Banking;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.DriverManager;

public class Database {
	private Connection connection;
	
	public Database()
	{
		
		try {
		
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","Sowmiya@2006");
		}
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public void insertAccount(Account account)
	{
		String sql="INSERT INTO accounts(customer_id,account_type,balance,name,phone_number,address) VALUES (?,?,?,?,?,?)";
		try(Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","Sowmiya@2006");
				PreparedStatement  pstmt=conn.prepareStatement(sql))
				{
					pstmt.setInt(1,account.getCustomerId());
					pstmt.setString(2,account.getAccountType());
					pstmt.setDouble(3,account.getBalance());
					pstmt.setString(4,account.getName());
					pstmt.setString(5,account.getPhoneNumber());
					pstmt.setString(6,account.getAddress());
					
					pstmt.executeUpdate();
				}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
			
		}
				}
	public void updateAccountBalance(Account account)
	{
		try {
			String query="Update accounts SET balance=? Where account_id=?";
			PreparedStatement statement=connection.prepareStatement(query);
			statement.setDouble(1,account.getBalance());
			statement.setInt(2,account.getAccountId());
			statement.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
			
	}
	public ArrayList <Account> getAllAccounts()
	{
		ArrayList<Account> accounts=new ArrayList<>();
		try
		{
			String query="Select * from accounts";
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(query);
			while(resultSet.next())
			{
				int accountid=resultSet.getInt("account_id");
				int customerid=resultSet.getInt("customer_id");
				String accountType=resultSet.getString("account_type");
				Double balance=resultSet.getDouble("balance");
				String name=resultSet.getString("name");
				String phoneNumber=resultSet.getString("phone_number");
				String address=resultSet.getString("address");
			
				Account account=new Account(customerid,accountType,name,phoneNumber,address);
				account.setAccountId(accountid);
				account.deposit(balance);
			    accounts.add(account);
		   }
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	
		return accounts;
	}
	public void updateAccountDetails(Account account)
	{
		String query="Update accounts set name=?,phone_number=?,address=?,balance=? where account_id=?";
		
				
				try(PreparedStatement preparedStatement=connection.prepareStatement(query))
				{
					preparedStatement.setString(1,account.getName());
					preparedStatement.setString(2,account.getPhoneNumber());
					preparedStatement.setString(3,account.getAddress());
					preparedStatement.setDouble(4,account.getBalance());
					preparedStatement.setInt(5,account.getAccountId());
					int rowsUpdated=preparedStatement.executeUpdate();
					if(rowsUpdated>0)
					{
						System.out.println("Account details updated successfully.");
					}
					else
					{
						System.out.println("No account found with the given ID");
					}
				}
				catch(SQLException e){
					e.printStackTrace();
					}
	}
	public void closeConnection()
	{
		try {
			if(connection!=null)
			{
				connection.close();
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	

}
